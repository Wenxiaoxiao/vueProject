<template>
	<div class="mine">mine</div>
</template>

<script>
	export default{name:'Mine'}
</script>

<style>
</style>