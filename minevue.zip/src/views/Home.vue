<template>
	<div class="home">{{name}}</div>
</template>

<script>
	export default{
		name:'Home',
		data(){
			return{
				name:'xionger'
			}
		},
		mounted:function(){
			console.log('aaaa');
		}
	}
</script>

<style>
</style>